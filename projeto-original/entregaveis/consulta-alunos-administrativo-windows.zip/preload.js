const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("adminApi", {
  savePackage: (payload) => ipcRenderer.invoke("save-package", payload),
});
