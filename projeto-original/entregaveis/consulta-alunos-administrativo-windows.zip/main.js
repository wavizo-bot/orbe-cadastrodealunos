const { app, BrowserWindow, dialog, ipcMain } = require("electron");
const fs = require("fs/promises");
const path = require("path");

function createWindow() {
  const window = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 1060,
    minHeight: 700,
    backgroundColor: "#F4F7FA",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  window.removeMenu();
  window.loadFile("index.html");
}

app.whenReady().then(() => {
  ipcMain.handle("save-package", async (_event, { content, fileName }) => {
    const { canceled, filePath } = await dialog.showSaveDialog({
      title: "Salvar arquivo de atualização",
      defaultPath: path.join(app.getPath("documents"), fileName),
      filters: [{ name: "Base Consulta de Alunos", extensions: ["cedb", "json"] }],
    });
    if (canceled || !filePath) {
      return { saved: false };
    }
    await fs.writeFile(filePath, content, "utf8");
    return { saved: true, filePath };
  });

  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
