# Consulta de Alunos — Administrativo Windows

Esta ferramenta cria e atualiza a base local consumida pelo aplicativo Android **Consulta de Alunos**. Ela não depende de servidor, conta de usuário ou internet durante a utilização.

## Uso direto em HTML no Windows

Sim, a ferramenta pode ser utilizada como HTML. Extraia os arquivos do pacote em uma pasta local e abra `index.html` com Microsoft Edge ou Google Chrome. O cadastro, a pesquisa, a importação de arquivos, a importação em massa, as fotos e a imagem institucional funcionam localmente no navegador. Ao escolher **EXPORTAR ATUALIZAÇÃO**, o navegador baixa o arquivo `.cedb`, que deverá ser transferido manualmente ao Android.

Essa alternativa não precisa de Node.js, Electron nem instalação. Basta manter `index.html`, `renderer.js` e `styles.css` juntos na mesma pasta. Não abra o arquivo dentro do ZIP: extraia primeiro a pasta completa. O arquivo `.cedb` gerado continua compatível com o menu **BANCO DE DADOS → IMPORTAR** do Android.

## Uso

Cadastre ou revise os estudantes, incluindo telefone do responsável, dados de perfil e a fotografia individual. A coluna de pesquisa permite localizar um aluno e o botão **REVISAR** abre o registro para correção e inclusão manual da foto. Se desejar, associe a imagem institucional exibida na pesquisa do Android. Ao selecionar **EXPORTAR ATUALIZAÇÃO**, a ferramenta produz um arquivo `.cedb`. Transfira esse arquivo ao aparelho Android e selecione **BANCO DE DADOS → IMPORTAR**.

## Importação em massa

A área **IMPORTAÇÃO EM MASSA** aceita dados colados de planilhas, texto separado por tabulações, CSV com vírgula ou ponto e vírgula, além de arquivos CSV, TSV e TXT. A primeira linha pode conter cabeçalhos reconhecidos como nome completo, responsável, telefone, nascimento, ano/série, sala, turno, condição e retirada autorizada. Sem cabeçalho, os campos devem estar nesta ordem:

`nome completo; responsável; telefone; nascimento; ano/série; sala; turno; condição; retirada autorizada`

As datas podem estar em `DD/MM/AAAA` ou `AAAA-MM-DD`. Na importação, a combinação nome completo + data de nascimento identifica o aluno para atualização. A foto já revisada é preservada quando os demais dados desse aluno são atualizados em massa.

Para a ativação trimestral, use o código que o Android mostra em 01 de janeiro, 01 de abril, 01 de julho ou 01 de novembro. Cole o código no campo apropriado e selecione **CALCULAR SENHA DE ATIVAÇÃO**. A senha resultante será a que deve ser escolhida no Android naquela data.

O botão **GERAR SENHA ALEATÓRIA** produz uma senha alternativa de quatro caracteres; por ser uma senha de uso local no Android, ela deve ser definida no próprio aparelho em **BANCO DE DADOS → GERAR SENHA**.

## Geração do executável para Windows

No diretório desta ferramenta, instale as dependências com `pnpm install` e execute `pnpm package:win`. O resultado é uma pasta Windows x64 em `release/`, contendo `Consulta-de-Alunos-Administrativo.exe`.
