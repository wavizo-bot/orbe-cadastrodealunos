const PASSWORD_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
const ACTIVATION_SALT = "CDA-ATIVACAO-2026";

let students = [];
let institutionalImageBase64 = "";
let currentPhotoBase64 = "";
let editingId = null;

const elements = {
  form: document.querySelector("#student-form"),
  formTitle: document.querySelector("#form-title"),
  studentCount: document.querySelector("#student-count"),
  studentList: document.querySelector("#students-list"),
  studentFilter: document.querySelector("#student-filter"),
  studentPhotoInput: document.querySelector("#student-photo-input"),
  photoReviewStatus: document.querySelector("#photo-review-status"),
  institutionalImageInput: document.querySelector("#institutional-image-input"),
  activationCodeInput: document.querySelector("#activation-code-input"),
  activationPasswordOutput: document.querySelector("#activation-password-output"),
  randomPasswordOutput: document.querySelector("#random-password-output"),
  packageFileInput: document.querySelector("#package-file-input"),
  bulkImportText: document.querySelector("#bulk-import-text"),
  bulkFileInput: document.querySelector("#bulk-file-input"),
  bulkImportSummary: document.querySelector("#bulk-import-summary"),
  toast: document.querySelector("#toast"),
};

const BULK_FIELD_NAMES = {
  "NOME": "nomeCompleto",
  "NOME COMPLETO": "nomeCompleto",
  "ALUNO": "nomeCompleto",
  "RESPONSAVEL": "nomeResponsavel",
  "NOME DO RESPONSAVEL": "nomeResponsavel",
  "TELEFONE": "telefoneResponsavel",
  "TELEFONE DO RESPONSAVEL": "telefoneResponsavel",
  "WHATSAPP": "telefoneResponsavel",
  "NASCIMENTO": "dataNascimento",
  "DATA DE NASCIMENTO": "dataNascimento",
  "DATA NASCIMENTO": "dataNascimento",
  "ANO": "anoSerie",
  "SERIE": "anoSerie",
  "ANO SERIE": "anoSerie",
  "ANO/SERIE": "anoSerie",
  "SALA": "sala",
  "TURNO": "turno",
  "CONDICAO": "condicaoEspecifica",
  "CONDICAO ESPECIFICA": "condicaoEspecifica",
  "DEFICIENCIA": "condicaoEspecifica",
  "RETIRADA": "retiradaAutorizada",
  "RETIRADA AUTORIZADA": "retiradaAutorizada",
};

const BULK_FIELD_ORDER = [
  "nomeCompleto",
  "nomeResponsavel",
  "telefoneResponsavel",
  "dataNascimento",
  "anoSerie",
  "sala",
  "turno",
  "condicaoEspecifica",
  "retiradaAutorizada",
];

function normalizeText(value) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim().toUpperCase();
}

function studentKey(student) {
  return `${normalizeText(student.nomeCompleto)}|${student.dataNascimento}`;
}

function normalizeHeader(value) {
  return normalizeText(value).replace(/[._-]+/g, " ").replace(/\s+/g, " ");
}

function parseDelimitedLine(line, delimiter) {
  const values = [];
  let value = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"' && line[index + 1] === '"') {
      value += '"';
      index += 1;
    } else if (character === '"') {
      quoted = !quoted;
    } else if (character === delimiter && !quoted) {
      values.push(value.trim());
      value = "";
    } else {
      value += character;
    }
  }
  values.push(value.trim());
  return values;
}

function detectDelimiter(firstLine) {
  if (firstLine.includes("\t")) return "\t";
  if (firstLine.includes(";")) return ";";
  return ",";
}

function normalizeDate(value) {
  const text = String(value || "").trim();
  const brazilianDate = text.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
  if (brazilianDate) {
    return `${brazilianDate[3]}-${brazilianDate[2].padStart(2, "0")}-${brazilianDate[1].padStart(2, "0")}`;
  }
  const isoDate = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (isoDate) {
    return `${isoDate[1]}-${isoDate[2].padStart(2, "0")}-${isoDate[3].padStart(2, "0")}`;
  }
  return text;
}

function parseBulkText(rawText) {
  const lines = rawText.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim());
  if (lines.length === 0) return [];
  const delimiter = detectDelimiter(lines[0]);
  const firstValues = parseDelimitedLine(lines[0], delimiter);
  const headers = firstValues.map((value) => BULK_FIELD_NAMES[normalizeHeader(value)] || null);
  const hasHeader = headers.some(Boolean);
  const dataLines = hasHeader ? lines.slice(1) : lines;
  return dataLines.map((line) => {
    const values = parseDelimitedLine(line, delimiter);
    const raw = {};
    values.forEach((value, index) => {
      const field = hasHeader ? headers[index] : BULK_FIELD_ORDER[index];
      if (field) raw[field] = value;
    });
    return raw;
  });
}

function prepareBulkStudent(raw, currentStudent) {
  const student = {
    id: currentStudent?.id || crypto.randomUUID(),
    nomeCompleto: String(raw.nomeCompleto || "").trim(),
    nomeResponsavel: String(raw.nomeResponsavel || "").trim(),
    telefoneResponsavel: String(raw.telefoneResponsavel || "").trim() || undefined,
    dataNascimento: normalizeDate(raw.dataNascimento),
    anoSerie: String(raw.anoSerie || "").trim(),
    sala: String(raw.sala || "").trim(),
    turno: String(raw.turno || "").trim(),
    fotoBase64: currentStudent?.fotoBase64,
    condicaoEspecifica: String(raw.condicaoEspecifica || "").trim() || undefined,
    retiradaAutorizada: String(raw.retiradaAutorizada || "").trim() || undefined,
    atualizadoEm: new Date().toISOString(),
  };
  const required = [student.nomeCompleto, student.nomeResponsavel, student.dataNascimento, student.anoSerie, student.sala, student.turno];
  return required.every(Boolean) ? student : null;
}

function mergeBulkStudents(rawStudents) {
  const indexByKey = new Map(students.map((student, index) => [studentKey(student), index]));
  const merged = [...students];
  let added = 0;
  let updated = 0;
  let ignored = 0;
  rawStudents.forEach((raw) => {
    const rawName = String(raw.nomeCompleto || "").trim();
    const rawBirth = normalizeDate(raw.dataNascimento);
    const currentIndex = rawName && rawBirth ? indexByKey.get(`${normalizeText(rawName)}|${rawBirth}`) : undefined;
    const student = prepareBulkStudent(raw, currentIndex === undefined ? undefined : merged[currentIndex]);
    if (!student) {
      ignored += 1;
      return;
    }
    const studentIndex = indexByKey.get(studentKey(student));
    if (studentIndex === undefined) {
      indexByKey.set(studentKey(student), merged.length);
      merged.push(student);
      added += 1;
    } else {
      merged[studentIndex] = student;
      updated += 1;
    }
  });
  students = merged;
  renderStudents();
  const summary = `${added} adicionado(s), ${updated} atualizado(s), ${ignored} linha(s) ignorada(s).`;
  elements.bulkImportSummary.textContent = summary;
  toast(`Importação em massa concluída: ${summary}`);
}

function positionInAlphabet(character) {
  if (/^[A-Z]$/.test(character)) return character.charCodeAt(0) - 65;
  if (/^[1-9]$/.test(character)) return Number(character) - 1;
  return null;
}

function hasSequentialPair(value) {
  for (let index = 1; index < value.length; index += 1) {
    const previous = value[index - 1];
    const current = value[index];
    const previousPosition = positionInAlphabet(previous);
    const currentPosition = positionInAlphabet(current);
    const sameClass = (/[A-Z]/.test(previous) && /[A-Z]/.test(current)) || (/[1-9]/.test(previous) && /[1-9]/.test(current));
    if (sameClass && previousPosition !== null && currentPosition !== null && Math.abs(previousPosition - currentPosition) === 1) return true;
  }
  return false;
}

function passwordFromNumbers(numbers) {
  const available = PASSWORD_ALPHABET.split("");
  const selected = [];
  let offset = 0;
  while (selected.length < 4 && offset < numbers.length * 4) {
    const index = numbers[offset % numbers.length] % available.length;
    const candidate = available.splice(index, 1)[0];
    if (!hasSequentialPair(`${selected.join("")}${candidate}`)) selected.push(candidate);
    offset += 1;
  }
  return selected.join("");
}

function secureRandomNumbers(length = 32) {
  const values = new Uint8Array(length);
  crypto.getRandomValues(values);
  return [...values];
}

function generatePassword() {
  let password = "";
  while (!password || password.length !== 4 || new Set(password).size !== 4 || hasSequentialPair(password)) {
    password = passwordFromNumbers(secureRandomNumbers());
  }
  return password;
}

async function passwordForActivationCode(code) {
  const data = new TextEncoder().encode(`${ACTIVATION_SALT}|${code.trim().toUpperCase()}`);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return passwordFromNumbers([...new Uint8Array(hash)]);
}

function toast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("visible");
  setTimeout(() => elements.toast.classList.remove("visible"), 3200);
}

function formatStudentMeta(student) {
  return [student.anoSerie, student.sala, student.turno].filter(Boolean).join(" · ");
}

function renderStudents() {
  const filter = normalizeText(elements.studentFilter.value || "");
  const filtered = students.filter((student) => normalizeText(student.nomeCompleto).includes(filter));
  elements.studentCount.textContent = String(students.length);
  elements.studentList.innerHTML = "";
  if (filtered.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-list";
    empty.textContent = students.length === 0 ? "Nenhum aluno cadastrado. Use o formulário ao lado para criar o primeiro registro." : "Nenhum aluno corresponde à pesquisa.";
    elements.studentList.append(empty);
    return;
  }

  const template = document.querySelector("#student-item-template");
  filtered
    .sort((a, b) => a.nomeCompleto.localeCompare(b.nomeCompleto, "pt-BR"))
    .forEach((student) => {
      const fragment = template.content.cloneNode(true);
      fragment.querySelector(".student-avatar").textContent = student.nomeCompleto.charAt(0).toUpperCase();
      fragment.querySelector(".student-name").textContent = student.nomeCompleto;
      fragment.querySelector(".student-meta").textContent = formatStudentMeta(student);
      fragment.querySelector(".edit").addEventListener("click", () => beginEdit(student.id));
      fragment.querySelector(".delete").addEventListener("click", () => deleteStudent(student.id));
      elements.studentList.append(fragment);
    });
}

function getField(id) { return document.querySelector(`#${id}`); }

function resetForm() {
  editingId = null;
  currentPhotoBase64 = "";
  elements.form.reset();
  elements.formTitle.textContent = "Novo aluno";
  elements.photoReviewStatus.textContent = "Nenhuma foto selecionada neste formulário.";
}

function beginEdit(id) {
  const student = students.find((item) => item.id === id);
  if (!student) return;
  editingId = id;
  currentPhotoBase64 = student.fotoBase64 || "";
  getField("nome-completo").value = student.nomeCompleto;
  getField("nome-responsavel").value = student.nomeResponsavel;
  getField("telefone-responsavel").value = student.telefoneResponsavel || "";
  getField("data-nascimento").value = student.dataNascimento;
  getField("ano-serie").value = student.anoSerie;
  getField("sala").value = student.sala;
  getField("turno").value = student.turno;
  getField("condicao-especifica").value = student.condicaoEspecifica || "";
  getField("retirada-autorizada").value = student.retiradaAutorizada || "";
  elements.formTitle.textContent = "Revisar aluno e foto";
  elements.photoReviewStatus.textContent = currentPhotoBase64 ? "Este aluno já possui uma foto; escolha outro arquivo para substituí-la." : "Este aluno ainda não possui foto. Selecione um arquivo para incluí-la.";
  document.querySelector(".form-panel").scrollIntoView({ behavior: "smooth", block: "start" });
}

function deleteStudent(id) {
  const student = students.find((item) => item.id === id);
  if (!student) return;
  if (!confirm(`Excluir o cadastro de ${student.nomeCompleto}?`)) return;
  students = students.filter((item) => item.id !== id);
  if (editingId === id) resetForm();
  renderStudents();
  toast("Cadastro removido da base administrativa.");
}

function getDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Não foi possível ler a imagem."));
    reader.readAsDataURL(file);
  });
}

async function onSaveStudent(event) {
  event.preventDefault();
  const student = {
    id: editingId || crypto.randomUUID(),
    nomeCompleto: getField("nome-completo").value.trim(),
    nomeResponsavel: getField("nome-responsavel").value.trim(),
    telefoneResponsavel: getField("telefone-responsavel").value.trim() || undefined,
    dataNascimento: getField("data-nascimento").value,
    anoSerie: getField("ano-serie").value.trim(),
    sala: getField("sala").value.trim(),
    turno: getField("turno").value,
    fotoBase64: currentPhotoBase64 || undefined,
    condicaoEspecifica: getField("condicao-especifica").value.trim() || undefined,
    retiradaAutorizada: getField("retirada-autorizada").value.trim() || undefined,
    atualizadoEm: new Date().toISOString(),
  };
  const duplicate = students.find((item) => studentKey(item) === studentKey(student) && item.id !== student.id);
  if (duplicate && !confirm("Já há um aluno com este nome e esta data de nascimento. Deseja substituí-lo?")) return;
  students = students.filter((item) => item.id !== student.id && studentKey(item) !== studentKey(student));
  students.push(student);
  resetForm();
  renderStudents();
  toast("Aluno salvo na base administrativa.");
}

function buildPackage() {
  return {
    formato: "consulta-alunos-import",
    versao: 1,
    exportadoEm: new Date().toISOString(),
    origem: "Consulta de Alunos — Administrativo Windows",
    imagemInstitucionalBase64: institutionalImageBase64 || undefined,
    alunos: students,
  };
}

function validatePackage(data) {
  return data && data.formato === "consulta-alunos-import" && data.versao === 1 && Array.isArray(data.alunos);
}

async function exportPackage() {
  const payload = JSON.stringify(buildPackage(), null, 2);
  const fileName = `consulta-alunos_${new Date().toISOString().slice(0, 10)}.cedb`;
  if (window.adminApi?.savePackage) {
    const result = await window.adminApi.savePackage({ content: payload, fileName });
    if (result.saved) toast(`Arquivo salvo em: ${result.filePath}`);
    return;
  }

  const blob = new Blob([payload], { type: "application/json;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(link.href);
  toast("Arquivo de atualização baixado pelo navegador.");
}

async function importPackage(file) {
  try {
    const raw = await file.text();
    const data = JSON.parse(raw);
    if (!validatePackage(data)) throw new Error("O arquivo não segue o formato Consulta de Alunos v1.");
    students = data.alunos;
    institutionalImageBase64 = data.imagemInstitucionalBase64 || "";
    resetForm();
    renderStudents();
    toast(`${students.length} aluno(s) carregado(s) do arquivo.`);
  } catch (error) {
    alert(error.message || "Não foi possível importar o arquivo.");
  }
}

function importBulkFromText(rawText) {
  const rows = parseBulkText(rawText);
  if (rows.length === 0) {
    alert("Cole pelo menos uma linha de aluno antes de importar.");
    return;
  }
  mergeBulkStudents(rows);
}

async function importBulkFile(file) {
  try {
    const raw = await file.text();
    if (/\.cedb$|\.json$/i.test(file.name)) {
      const parsed = JSON.parse(raw);
      if (validatePackage(parsed)) {
        await importPackage(file);
        return;
      }
    }
    importBulkFromText(raw);
  } catch (error) {
    alert(error.message || "Não foi possível importar o arquivo selecionado.");
  }
}

elements.form.addEventListener("submit", onSaveStudent);
elements.studentFilter.addEventListener("input", renderStudents);
document.querySelector("#clear-form-button").addEventListener("click", resetForm);
document.querySelector("#cancel-edit-button").addEventListener("click", resetForm);
document.querySelector("#remove-photo-button").addEventListener("click", () => { currentPhotoBase64 = ""; elements.studentPhotoInput.value = ""; elements.photoReviewStatus.textContent = "Foto removida deste formulário."; toast("Foto removida do formulário."); });
elements.studentPhotoInput.addEventListener("change", async (event) => { const file = event.target.files[0]; if (!file) return; currentPhotoBase64 = await getDataUrl(file); elements.photoReviewStatus.textContent = `Foto pronta para salvar: ${file.name}`; toast("Foto adicionada ao cadastro."); });
elements.institutionalImageInput.addEventListener("change", async (event) => { const file = event.target.files[0]; if (!file) return; institutionalImageBase64 = await getDataUrl(file); toast("Imagem institucional adicionada à próxima exportação."); });
document.querySelector("#remove-institutional-image-button").addEventListener("click", () => { institutionalImageBase64 = ""; elements.institutionalImageInput.value = ""; toast("Imagem institucional removida."); });
document.querySelector("#random-password-button").addEventListener("click", () => { elements.randomPasswordOutput.textContent = generatePassword(); });
document.querySelector("#activation-password-button").addEventListener("click", async () => {
  const code = elements.activationCodeInput.value.trim();
  if (!/^ATV-\d{6}-[A-Z0-9]{6}$/i.test(code)) { alert("Informe um código no formato ATV-AAAAMM-XXXXXX."); return; }
  elements.activationPasswordOutput.textContent = await passwordForActivationCode(code);
});
document.querySelector("#export-button").addEventListener("click", () => void exportPackage());
document.querySelector("#import-button").addEventListener("click", () => elements.packageFileInput.click());
elements.packageFileInput.addEventListener("change", (event) => { const file = event.target.files[0]; if (file) void importPackage(file); event.target.value = ""; });
document.querySelector("#bulk-import-text-button").addEventListener("click", () => importBulkFromText(elements.bulkImportText.value));
document.querySelector("#bulk-import-file-button").addEventListener("click", () => elements.bulkFileInput.click());
elements.bulkFileInput.addEventListener("change", (event) => { const file = event.target.files[0]; if (file) void importBulkFile(file); event.target.value = ""; });

renderStudents();
